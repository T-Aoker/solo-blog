title: 我的solo终于搞定啦
date: '2019-12-02 23:38:03'
updated: '2019-12-02 23:38:03'
tags: [随笔]
permalink: /articles/2019/12/02/1575301083540.html
---
我的solo终于搞定啦！！！！
真的太难了![u28769061071835500173fm26gp0.jpg](https://img.hacpai.com/file/2019/12/u28769061071835500173fm26gp0-8c239568.jpg)

